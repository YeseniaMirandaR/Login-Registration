const express = require( 'express' );
const mongoose = require( 'mongoose' );
const bcrypt = require( 'bcrypt' );
const session = require( 'express-session' );
const flash = require( 'express-flash' );


mongoose.connect('mongodb://localhost/loginregist_db', {useNewUrlParser: true});

const {UserModel} = require( './models/userModel' );
const app = express();

app.set( 'views', __dirname + '/views' );
app.set( 'view engine', 'ejs' );

app.use( flash() );
app.use( express.urlencoded({extended:true}) );
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 * 10 }
}));

app.get( '/', function( request, response ){
    response.render( 'login' );
});

app.post( '/users/addUser', function( request, response ){
    const firstName = request.body.firstName;
    const lastName = request.body.lastName;
    const birthday = request.body.birthday;
    const email = request.body.email;
    const password = request.body.password;

    bcrypt.hash( password, 10 )
        .then( encryptedPassword => {
            const newUser = {
                firstName,
                lastName,
                birthday,
                email,
                password : encryptedPassword
            };
            console.log( newUser );
            UserModel
                .createUser( newUser )
                .then( result => {
                    request.session.firstName = result.firstName;
                    request.session.lastName = result.lastName;
                    request.session.birthday = result.birthday;
                    request.session.email = result.email;
                    response.redirect( '/users' );
                })
                .catch( err => {
                    request.flash( 'registration', 'Check: 1. All fields are required./ 2. First and Last Name must be greater than 3./ 3. Email must be valid. / 4. That username is already in use.' );
                    response.redirect( '/' );
                });
        });
});

app.post( '/users/login', function( request, response ){
    let email = request.body.loginEmail;
    let password = request.body.loginPassword;

    UserModel
        .getUserById( email )
        .then( result => {
            console.log( "Result", result );
            console.log('EncryptedPSW', result.password)
            if( result === null ){
                throw new Error( "That user doesn't exist!" );
            }

            bcrypt.compare( password, result.password )
                .then( flag => {
                    //console.log('BCRYPT_FLAG', flag)
                    if( !flag ){
                        throw new Error( "Wrong credentials!" );
                    }
                    request.session.firstName = result.firstName;
                    request.session.lastName = result.lastName;
                    request.session.email = result.email;

                    response.redirect( '/users' );
                })
                .catch( error => {
                    request.flash( 'login', error.message );
                    response.redirect( '/' );
                }); 
        })
        .catch( error => {
            request.flash( 'login', error.message );
            response.redirect( '/' );
        });
});

app.post( '/logout', function( request, response ){
    request.session.destroy();
    response.redirect( '/' ); 
});

app.get( '/users', function( request, response ){
    if( request.session.email === undefined ){
        response.redirect( '/' );
    }
    else{
        UserModel
            .getUsers()
            .then( data => {
                console.log( data );
                let currentUser = {
                    firstName : request.session.firstName, 
                    lastName : request.session.lastName,
                    birthday : request.session.birthday,
                    email : request.session.email
                }
                response.render( 'index', { users : data, currentUser } );
            });
    }
});

app.listen( 8080, function(){
    console.log( "The users server is running in port 8080." );
});